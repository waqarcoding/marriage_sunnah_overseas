// @ts-nocheck
import React, { useRef, useCallback, useState } from "react";
import { useQuery } from "@tanstack/react-query";

function useCachedImage(src) {
    return useQuery({
        queryKey: ["img", src],
        queryFn: () => new Promise((resolve, reject) => {
            if (!src) return reject("no src");
            const img = new Image();
            img.onload = () => {
                console.log("✅ Image loaded:", src);
                resolve(src);
            };
            img.onerror = (e) => {
                console.log("❌ Image failed to load:", src, e);
                reject("failed");
            };
            img.src = src;
        }),
        enabled: !!src,
        staleTime: Infinity,
        gcTime: Infinity,
        retry: false,
    });
}

export function formatLastSeen(dateStr) {
    if (!dateStr) return "";
    const diff = Math.floor((Date.now() - new Date(dateStr)) / 1000);
    if (diff < 60) return "just now";
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return `${Math.floor(diff / 86400)}d ago`;
}

export function isOnline(dateStr) {
    if (!dateStr) return false;
    return Math.floor((Date.now() - new Date(dateStr)) / 1000) < 3600;
}

export function LastSeenBadge({ profile, viewerIsPro = false }) {
    const profileCanShowIt = profile?.is_pro && profile?.show_last_seen !== false;
    if (!profileCanShowIt || !viewerIsPro) return null;

    const online = isOnline(profile.last_seen);
    const seen = formatLastSeen(profile.last_seen);
    if (!seen) return null;

    return (
        <div className="flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full flex-shrink-0 ${online ? "bg-green-400 animate-pulse" : "bg-gray-400"}`} />
            <span className="text-xs" style={{ color: online ? "#10b981" : "#9ca3af" }}>
                {online ? "Online" : (seen === "0m ago" ? "just now" : seen)}
            </span>
        </div>

    );
}

function GenderPlaceholder({ gender }) {
    console.log("🖼️ GenderPlaceholder rendering, gender:", gender);
    const isFemale = gender?.toLowerCase() === "female";
    return (
        <span className="flex items-center justify-center w-full h-full rounded-[inherit] bg-card">
            {isFemale ? (
                <svg viewBox="0 0 24 24" fill="currentColor" className="w-1/2 h-1/2 text-muted-foreground/50">
                    <path d="M12 2a5 5 0 1 1 0 10A5 5 0 0 1 12 2zm0 12c3.17 0 6 1.34 6 3v1H6v-1c0-1.66 2.83-3 6-3zm1 4v4h-2v-4h-2v-2h6v2h-2z" />
                </svg>
            ) : (
                <svg viewBox="0 0 24 24" fill="currentColor" className="w-1/2 h-1/2 text-muted-foreground/50">
                    <path d="M12 2a5 5 0 1 1 0 10A5 5 0 0 1 12 2zm0 12c3.17 0 6 1.34 6 3v1H6v-1c0-1.66 2.83-3 6-3z" />
                </svg>
            )}
        </span>
    );
}

function SpinnerAvatar() {
    return (
        <span className="absolute inset-0 flex items-center justify-center z-10 pointer-events-none">
            <span className="block w-6 h-6 border-4 border-white/40 border-t-white border-b-white/60 rounded-full animate-spin" />
        </span>
    );
}

export default function ImageAvatar({
    images,
    gender,
    alt = "",
    className = "",
    interestStatus = "pending",
    isShowPending = true,
    isBlurred = false,
    viewerIsPro = false,
    shouldShowOverlay = true,
}) {
    const [imgFailed, setImgFailed] = useState(false);

    const src = React.useMemo(() => {
        console.log("🔍 ImageAvatar images prop:", images);
        if (Array.isArray(images) && typeof images[0] === "string") return images[0];
        if (typeof images === "string" && images.trim()) {
            try {
                const arr = JSON.parse(images);
                if (Array.isArray(arr) && typeof arr[0] === "string") return arr[0];
            } catch (_) { }
            if (images.startsWith("http")) return images;
        }
        console.log("⚠️ No valid src found from images:", images);
        return null;
    }, [images]);

    console.log("🔍 src resolved to:", src);

    const { data: resolvedSrc, isLoading, isError, status } = useCachedImage(src);

    console.log("📊 useCachedImage state — status:", status, "| isLoading:", isLoading, "| isError:", isError, "| resolvedSrc:", resolvedSrc);

    const imgRef = useRef(null);

    const handleLoad = useCallback(() => {
        console.log("✅ img tag onLoad fired");
        if (imgRef.current) imgRef.current.style.opacity = "1";
    }, []);

    const showFallback = !src || isError || imgFailed || (!isLoading && !resolvedSrc);
    const shouldBlur = isBlurred && !viewerIsPro;

    console.log("🧩 Render decision — showFallback:", showFallback, "| isLoading:", isLoading, "| imgFailed:", imgFailed, "| shouldBlur:", shouldBlur);

    return (
        <span className={`relative block overflow-hidden ${className}`}>
            <span className="relative block w-full h-full overflow-hidden rounded-[inherit]">

                {isLoading && (
                    <>
                        {console.log("⏳ Showing spinner")}
                        <SpinnerAvatar />
                    </>
                )}

                {!isLoading && showFallback && (
                    <>
                        {console.log("🖼️ Showing GenderPlaceholder")}
                        <GenderPlaceholder gender={gender} />
                    </>
                )}

                {!isLoading && !showFallback && resolvedSrc && (
                    <>
                        {console.log("🖼️ Showing img tag with src:", resolvedSrc)}
                        <img
                            ref={imgRef}
                            src={resolvedSrc}
                            alt={shouldBlur ? "" : alt}
                            decoding="async"
                            className="bg-card object-cover w-full h-full rounded-[inherit] block"
                            style={{
                                aspectRatio: "1 / 1",
                                opacity: 0,
                                transition: "opacity 0.15s ease",
                                filter: shouldBlur ? "blur(2px)" : "none",
                                transform: shouldBlur ? "scale(1.1)" : "none",
                            }}
                            onLoad={handleLoad}
                            onError={(e) => {
                                console.log("❌ img tag onError fired for:", resolvedSrc);
                                setImgFailed(true);
                            }}
                        />
                    </>
                )}

                {shouldBlur && shouldShowOverlay && !isLoading && (
                    <span
                        className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-1 cursor-pointer"
                        onClick={() => window.location.href = "/subscription"}
                        role="button"
                        tabIndex={0}
                        onKeyDown={e => {
                            if (e.key === 'Enter' || e.key === ' ') {
                                window.location.href = "/subscription";
                            }
                        }}
                        style={{ outline: "none" }}
                    >
                        <span style={{ fontSize: "22px" }}>🔒</span>
                        <span
                            className="text-white text-[10px] font-bold text-center px-2 leading-tight"
                            style={{ textShadow: "0 1px 4px rgba(0,0,0,0.8)" }}
                        >
                            Upgrade to view
                        </span>
                    </span>
                )}
            </span>

            {!shouldBlur && !isLoading && !showFallback && (
                <span className="pointer-events-none absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-black/70 to-transparent z-10" />
            )}
        </span>
    );
}