import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Sparkles, Eye, MessageCircle, Star, Zap, Crown, Heart, Users } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import SubscriptionService from "../services/SubscriptionService";
import AuthApi from "../../auth/services/AuthService"; // ✅ Import AuthApi
import AuthService from "../../auth/services/AuthService";

// ── Background Video Player ──────────────────────────────────────────────────
function BackgroundVideo() {
    const [currentIndex] = useState(0);
    const playlist = ['/image1.jpg'];

    return (
        <div className="absolute inset-0 overflow-hidden">
            <div
                className="absolute inset-0"
                style={{
                    backgroundImage: `url(${playlist[currentIndex]})`,
                    backgroundSize: "cover",


                    backgroundPosition: "center",
                    filter: "blur(2px)",
                    transform: "scale(1)",
                }}
            />
            <div
                className="absolute inset-0"
                style={{
                    background: "linear-gradient(180deg, rgba(27,77,62,0.6) 0%, rgba(27,77,62,0.92) 60%, var(--primary) 100%)",
                }}
            />
        </div>
    );
}

// ── Top Bar ──────────────────────────────────────────────────────────────────
function TopBar() {
    const navigate = useNavigate();

    return (
        <div className="flex items-center justify-between px-2 py-2">
            <button
                onClick={() => navigate(-1)}
                className="w-10 h-10 flex items-center justify-center"
            >
                <X size={24} style={{ color: "var(--background)", opacity: 0.7 }} />
            </button>
            <div
                className="px-3 py-1.5 rounded-full flex items-center gap-1.5"
                style={{
                    background: "var(--background)",
                }}
            >
                <Sparkles size={12} color="#111111" fill="#111111" />
                <span style={{ color: "#111111", fontSize: "11px", fontWeight: 700 }}>
                    PRO
                </span>
            </div>
        </div>
    );
}

// ── Hero Section ─────────────────────────────────────────────────────────────
function HeroSection() {
    return (
        <div className="text-center px-5">
            <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2, duration: 0.5 }}
                style={{
                    fontSize: "26px",
                    fontWeight: 700,
                    color: "var(--background)",
                    lineHeight: 1.3,
                    marginTop: "16px",
                    marginBottom: "8px",
                }}
            >
                Unlock Unlimited
                <br />
                Connections
            </motion.h1>

            <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3, duration: 0.5 }}
                style={{
                    fontSize: "14px",
                    color: "var(--primary-foreground)",
                    opacity: 0.8,
                }}
            >
                Go Pro and find your perfect match without limits
            </motion.p>
        </div>
    );
}

// ── Features List ────────────────────────────────────────────────────────────
function FeaturesList() {
    const features = [
        { icon: Eye, text: "See who liked you" },
        { icon: Zap, text: "Unlimited likes" },
        { icon: MessageCircle, text: "Chat unlock" },
        { icon: Star, text: "More appearance" },

        { icon: Crown, text: "Premium badge" },
        { icon: Heart, text: "See full match compatibility" },
        { icon: Users, text: "Family visibility boost" },




    ];

    return (
        <div className="space-y-4">
            {features.map(({ icon: Icon, text }, i) => (
                <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.4 + i * 0.1, duration: 0.3 }}
                    className="flex items-center justify-between"
                >
                    <div className="flex items-center gap-3">
                        <Icon size={20} style={{ color: "var(--accent)" }} />
                        <span style={{ fontSize: "17px", color: "var(--background)" }}>
                            {text}
                        </span>
                    </div>
                    <div
                        className="flex items-center justify-center"
                        style={{
                            width: "24px",
                            height: "24px",
                            borderRadius: "50%",
                            background: "#10b981",
                        }}
                    >
                        <svg width="14" height="11" viewBox="0 0 14 11" fill="none">
                            <path
                                d="M1 5.5L5 9.5L13 1.5"
                                stroke="#ffffff"
                                strokeWidth="2.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                            />
                        </svg>
                    </div>
                </motion.div>
            ))}
        </div>
    );
}

// ── Pricing Cards ────────────────────────────────────────────────────────────
function PricingCards({ onSelect, selected }) {
    const plans = SubscriptionService.getPlans();

    return (
        <div className="space-y-3">
            {plans.map((pkg, i) => {
                const isSelected = selected?.id === pkg.id;
                return (
                    <motion.button
                        key={pkg.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.8 + i * 0.1, duration: 0.4 }}
                        onClick={() => onSelect(pkg)}
                        className="w-full p-4 rounded-3xl text-left"
                        style={{

                            background: isSelected ? "#ffffff" : "#1B4D3E",
                            color: isSelected ? "#ffffff" : "#ffffff",


                            border: `2px solid ${isSelected ? "#1B4D3E" : "transparent"}`,
                            transition: "all 0.2s ease",
                            boxShadow: isSelected ? "0 4px 16px rgba(27,77,62,0.3)" : "none",
                        }}
                    >
                        <div className="flex items-center justify-between">
                            <div>
                                <div className="flex items-center gap-2 mb-1.5">
                                    <span style={{
                                        fontSize: "16px",
                                        fontWeight: 700,
                                        color: isSelected ? "#1B4D3E" : "#ffffff",

                                        letterSpacing: "0.5px",
                                    }}>
                                        {pkg.label}
                                    </span>
                                    {pkg.popular && (
                                        <span style={{
                                            fontSize: "9px",
                                            fontWeight: 700,
                                            color: isSelected ? "#ffffff" : "#ffffff",

                                            background: "linear-gradient(135deg, #6366f1, #8b5cf6)",
                                            padding: "2px 6px",
                                            borderRadius: "8px",
                                        }}>
                                            BEST VALUE
                                        </span>
                                    )}
                                </div>
                                <div className="flex items-center gap-2">
                                    <Zap size={14} style={{
                                        color: isSelected ? "#1B4D3E" : "#ffffff",
                                        fill: isSelected ? "#1B4D3E" : "#ffffff",

                                    }} />
                                    <span style={{
                                        fontSize: "15px",
                                        color: isSelected ? "#1B4D3E" : "#ffffff",

                                        fontWeight: 500,
                                        opacity: 0.8,
                                    }}>
                                        {pkg.credits} credits
                                    </span>
                                </div>
                            </div>
                            <div style={{
                                fontSize: "28px",
                                fontWeight: 700,
                                color: isSelected ? "#1B4D3E" : "#ffffff",

                            }}>
                                {pkg.price}
                            </div>
                        </div>
                    </motion.button>
                );
            })}
        </div>
    );
}

// ── Current Subscription Info ────────────────────────────────────────────────
function CurrentSubscriptionInfo({ userStatus }) {
    if (!userStatus?.activeSubscription || userStatus.isExpired) return null;

    return (
        <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            style={{
                padding: "16px",
                background: "rgba(245, 240, 232, 0.15)",
                borderRadius: "16px",
                border: "1px solid rgba(245, 240, 232, 0.2)",
            }}
        >
            <div style={{ marginBottom: "8px" }}>
                <span style={{
                    fontSize: "12px",
                    color: "var(--background)",
                    opacity: 0.6,
                    textTransform: "uppercase",
                    letterSpacing: "0.5px",
                    fontWeight: 600
                }}>
                    Current Plan
                </span>
            </div>
            <div style={{
                fontSize: "18px",
                color: "var(--background)",
                fontWeight: 700,
                marginBottom: "8px"
            }}>
                {userStatus.activeSubscription.plan_type.toUpperCase()}
            </div>
            <div style={{
                fontSize: "14px",
                color: "var(--background)",
                opacity: 0.7,
                marginBottom: "12px"
            }}>
                <strong>{userStatus.credits}</strong> credits remaining
                <br />
                Renews {new Date(userStatus.subscriptionExpiresAt).toLocaleDateString()}
            </div>
            <div style={{
                fontSize: "13px",
                color: "var(--accent)",
                fontWeight: 600,
                display: "flex",
                alignItems: "center",
                gap: "4px"
            }}>
                <Sparkles size={14} />
                Upgrade to keep your {userStatus.credits} credits and get more!
            </div>
        </motion.div>
    );
}

// ── Main Page ────────────────────────────────────────────────────────────────
export default function SubscriptionPage() {
    const navigate = useNavigate();
    const queryClient = useQueryClient();
    const [selectedPlan, setSelectedPlan] = useState(null);
    const [isProcessing, setIsProcessing] = useState(false);
    const [isSuccess, setIsSuccess] = useState(false);
    const [error, setError] = useState(null);

    // ✅ Get user ID from AuthApi
    const [userId, setUserId] = useState(null);
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    // In subscriptions.jsx
    useEffect(() => {
        const plans = SubscriptionService.getPlans();
        handlePlanSelect(plans[2]);
        const userId = AuthService.getUserId();


        const isLoggedIn = AuthService.isLoggedIn();

    }, []);
    useEffect(() => {
        let isMounted = true;
        async function fetchUserInfo() {
            const fetchedUserId = await AuthApi.getUserId();
            const fetchedIsLoggedIn = await AuthApi.isLoggedIn();

            if (isMounted) {
                setUserId(fetchedUserId);
                setIsLoggedIn(fetchedIsLoggedIn);
            }
        }
        fetchUserInfo();

        document.body.style.background = "var(--primary)";
        return () => {
            isMounted = false;
            document.body.style.background = "";
        };
    }, [navigate]);

    // Fetch subscription status using React Query
    const { data: userStatus, isLoading: statusLoading } = useQuery({
        queryKey: ['subscription-status', userId],
        queryFn: () => SubscriptionService.getSubscriptionStatus(userId),
        enabled: !!userId && isLoggedIn,
        select: (response) => response,
        staleTime: 5 * 60 * 1000,
        retry: 1,
    });

    const handlePlanSelect = (plan) => {
        setSelectedPlan(plan);
        setError(null);
    };

    const handlePurchase = async () => {
        // ✅ Double check authentication
        if (!userId || !isLoggedIn) {
            setError("Please login to continue");
            navigate('/login', { state: { from: '/subscription' } });
            return;
        }

        if (!selectedPlan?.stripePriceId) {
            setError("Please select a plan");
            return;
        }

        setIsProcessing(true);
        setError(null);

        try {
            console.log('Creating checkout session with:', {
                priceId: selectedPlan.stripePriceId,
                userId: userId,
                planType: selectedPlan.id,
                credits: selectedPlan.credits
            });

            const response = await SubscriptionService.createCheckoutSession({
                priceId: selectedPlan.stripePriceId,
                userId: userId,
                planType: selectedPlan.id,
                credits: selectedPlan.credits
            });

            if (response?.url) {
                window.location.href = response.url;
            } else {
                throw new Error('No checkout URL received');
            }
        } catch (err) {
            console.error('Subscription error:', err);
            const errorMessage = err.response?.error
                || err.message
                || 'Failed to start subscription';
            setError(errorMessage);
            setIsProcessing(false);
        }
    };

    const handleRestore = async () => {
        if (!userId || !isLoggedIn) {
            setError("Please login to continue");
            return;
        }

        setIsProcessing(true);
        setError(null);

        try {
            const response = await SubscriptionService.restorePurchases(userId);

            if (response?.success) {
                // @ts-ignore
                queryClient.invalidateQueries(['subscription-status', userId]);
                setIsSuccess(true);
                setTimeout(() => navigate(-1), 2000);
            } else {
                setError(response?.message || 'No Restore Found!');
            }
        } catch (err) {
            console.error('Restore error:', err);
            setError(err.response?.error || 'Failed to restore purchases');
        } finally {
            setIsProcessing(false);
        }
    };


    // Loading state
    if (statusLoading) {
        return (
            <div
                style={{
                    minHeight: "100vh",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    background: "var(--primary)",
                }}
            >
                <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                    style={{
                        width: "40px",
                        height: "40px",
                        border: "4px solid rgba(245,240,232,0.2)",
                        borderTopColor: "var(--primary-foreground)",
                        borderRadius: "50%",
                    }}
                />
            </div>
        );
    }

    return (
        <div
            className="relative min-h-screen overflow-hidden"
            style={{
                fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
                background: "var(--primary)",
            }}
        >
            <BackgroundVideo />

            <div className="relative z-10 min-h-screen flex flex-col">
                <TopBar />

                <div className="flex-1 overflow-y-auto px-5 pb-5">
                    <div className="space-y-7">
                        <div className="mt-5">
                            <HeroSection />
                        </div>

                        <FeaturesList />

                        <CurrentSubscriptionInfo userStatus={userStatus} />

                        <PricingCards onSelect={handlePlanSelect} selected={selectedPlan} />

                        {/* Error Message */}
                        {error && (
                            <motion.div
                                initial={{ opacity: 0, y: -10 }}
                                animate={{ opacity: 1, y: 0 }}
                                style={{
                                    padding: "12px 16px",
                                    background: "rgba(239, 68, 68, 0.1)",
                                    border: "1px solid rgba(239, 68, 68, 0.3)",
                                    borderRadius: "12px",
                                    color: "#ef4444",
                                    fontSize: "14px",
                                    textAlign: "center"
                                }}
                            >
                                {error}
                            </motion.div>
                        )}

                        {/* Subscribe Button */}
                        <AnimatePresence mode="wait">
                            {isSuccess ? (
                                <motion.div
                                    key="success"
                                    initial={{ scale: 0.9, opacity: 0 }}
                                    animate={{ scale: 1, opacity: 1 }}
                                    exit={{ scale: 0.9, opacity: 0 }}
                                    className="w-full py-4 rounded-2xl font-bold text-center flex items-center justify-center gap-2"
                                    style={{
                                        background: "#10b981",
                                        color: "#ffffff",
                                        fontSize: "16px",
                                        boxShadow: "0 4px 20px rgba(16, 185, 129, 0.4)",
                                    }}
                                >
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                                        <path
                                            d="M20 6L9 17L4 12"
                                            stroke="#ffffff"
                                            strokeWidth="3"
                                            strokeLinecap="round"
                                            strokeLinejoin="round"
                                        />
                                    </svg>
                                    Success! Welcome to Premium
                                </motion.div>
                            ) : (
                                <motion.button
                                    key="subscribe"
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: 1.1, duration: 0.4 }}
                                    whileTap={{ scale: 0.98 }}
                                    onClick={handlePurchase}
                                    disabled={isProcessing || !selectedPlan}
                                    className="w-full py-4 rounded-2xl font-bold text-center flex items-center justify-center gap-2"
                                    style={{
                                        background: "#ffffff",

                                        color: "#111111",

                                        fontSize: "16px",
                                        boxShadow: "0 4px 20px #ffffff",


                                        opacity: (isProcessing || !selectedPlan) ? 0.7 : 1,
                                        cursor: (isProcessing || !selectedPlan) ? "not-allowed" : "pointer",
                                    }}
                                >
                                    {isProcessing ? (
                                        <>
                                            <motion.div
                                                animate={{ rotate: 360 }}
                                                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                                                style={{
                                                    width: "20px",
                                                    height: "20px",
                                                    border: "3px solid rgba(255,255,255,0.3)",
                                                    borderTopColor: "#ffffff",
                                                    borderRadius: "50%",
                                                }}
                                            />
                                            Processing...
                                        </>
                                    ) : (
                                        <>
                                            {userStatus?.activeSubscription && !userStatus.isExpired
                                                ? `Upgrade Now ${selectedPlan ? `- ${selectedPlan.price}` : ''}`
                                                : `Subscribe Now ${selectedPlan ? `- ${selectedPlan.price}` : ''}`
                                            }
                                        </>
                                    )}
                                </motion.button>
                            )}
                        </AnimatePresence>

                        {/* Restore Button */}
                        <motion.button
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: 1.2, duration: 0.4 }}
                            onClick={handleRestore}
                            disabled={isProcessing}
                            className="w-full py-3"
                            style={{
                                fontSize: "16px",
                                fontWeight: 600,
                                color: "var(--background)",
                                opacity: isProcessing ? 0.4 : 0.6,
                                textAlign: "center",
                                cursor: isProcessing ? "not-allowed" : "pointer",
                            }}
                        >
                            Restore Purchases
                        </motion.button>

                        {/* Powered by Stripe */}
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: 1.25, duration: 0.4 }}
                            className="flex items-center justify-center gap-2 py-2"
                        >
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--primary-foreground)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.5">
                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                                <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                            </svg>
                            <span style={{
                                fontSize: "12px",
                                color: "var(--background)",
                                opacity: 0.5,
                            }}>
                                Powered by Stripe
                            </span>
                        </motion.div>

                        {/* Legal Text */}
                        <motion.p
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: 1.3, duration: 0.4 }}
                            style={{
                                fontSize: "10px",
                                color: "var(--background)",
                                opacity: 0.4,
                                textAlign: "center",
                                lineHeight: 1.5,
                            }}
                        >
                            Subscriptions auto-renew unless cancelled.
                        </motion.p>
                    </div>
                </div>
            </div>
        </div>
    );
}