import Api from "../../../api/Api";

// @ts-ignore
const BASE_URL = import.meta.env.VITE_BASE_URL ?? "";

class SubscriptionService {
    constructor() {
        this.base = "/subscription";
    }

    /**
     * Create Stripe checkout session
     * @param {Object} data - { priceId, userId, planType, credits }
     * @returns {Promise} - Returns { url } for Stripe Checkout redirect
     */
    createCheckoutSession(data) {
        return Api.post(`${this.base}/create-checkout-session`, data);
    }

    /**
     * Get user subscription status
     * @param {number|string} userId - User ID
     * @returns {Promise} - Returns subscription status data
     */
    getSubscriptionStatus(userId) {
        return Api.get(`${this.base}/status/${userId}`);
    }

    /**
     * Restore previous purchases
     * @param {number|string} userId - User ID
     * @returns {Promise} - Returns restore status
     */
    restorePurchases(userId) {
        return Api.post(`${this.base}/restore-purchases`, { userId });
    }

    /**
     * Verify Stripe checkout session
     * @param {string} sessionId - Stripe session ID
     * @returns {Promise} - Returns session verification data
     */
    verifySession(sessionId) {
        return Api.get(`${this.base}/verify-session?session_id=${sessionId}`);
    }

    /**
     * Get user's subscription history
     * @param {number|string} userId - User ID
     * @param {Object} params - Query parameters (optional)
     * @returns {Promise} - Returns subscription history
     */
    getSubscriptionHistory(userId, params = {}) {
        const query = new URLSearchParams(params).toString();
        const endpoint = query
            ? `${this.base}/history/${userId}?${query}`
            : `${this.base}/history/${userId}`;
        return Api.get(endpoint);
    }

    /**
     * Get user's transaction history
     * @param {number|string} userId - User ID
     * @param {Object} params - Query parameters (optional)
     * @returns {Promise} - Returns transaction history
     */
    getTransactionHistory(userId, params = {}) {
        const query = new URLSearchParams(params).toString();
        const endpoint = query
            ? `${this.base}/transactions/${userId}?${query}`
            : `${this.base}/transactions/${userId}`;
        return Api.get(endpoint);
    }

    /**
     * Cancel active subscription
     * @param {number|string} userId - User ID
     * @returns {Promise} - Returns cancellation status
     */
    cancelSubscription(userId) {
        return Api.post(`${this.base}/cancel`, { userId });
    }

    /**
     * Check if user should see subscription page
     * @param {number|string} userId - User ID
     * @returns {Promise<boolean>} - Returns true if subscription expired and credits empty
     */
    async shouldShowSubscriptionPage(userId) {
        try {
            const response = await this.getSubscriptionStatus(userId);
            const { data } = response;
            return data?.shouldShowSubscriptionPage || false;
        } catch (error) {
            console.error('Error checking subscription page visibility:', error);
            return false;
        }
    }

    /**
     * Get available subscription plans
     * @returns {Array} - Returns array of subscription plans
     */
    getPlans() {
        return [
            {
                id: "weekly",
                label: "WEEKLY",
                credits: 50,
                price: "$4.99",
                priceValue: 4.99,
                durationDays: 7,
                // @ts-ignore
                stripePriceId: import.meta.env.VITE_STRIPE_WEEKLY_PRICE_ID,
            },
            {
                id: "monthly",
                label: "MONTHLY",
                credits: 250,
                price: "$12.99",
                priceValue: 12.99,
                durationDays: 30,
                // @ts-ignore
                stripePriceId: import.meta.env.VITE_STRIPE_MONTHLY_PRICE_ID,
            },
            {
                id: "yearly",
                label: "YEARLY",
                credits: 3500,
                price: "$71.88",
                priceValue: 71.88,
                durationDays: 365,
                popular: true,
                // @ts-ignore
                stripePriceId: import.meta.env.VITE_STRIPE_YEARLY_PRICE_ID,
            },
        ];
    }

    /**
     * Calculate credits per dollar for each plan
     * @returns {Array} - Plans with creditsPerDollar calculated
     */
    getPlansWithValue() {
        const plans = this.getPlans();
        return plans.map(plan => ({
            ...plan,
            creditsPerDollar: (plan.credits / plan.priceValue).toFixed(2),
        }));
    }

    /**
     * Format subscription expiry date
     * @param {string|Date} expiryDate - Expiry date
     * @returns {string} - Formatted date string
     */
    formatExpiryDate(expiryDate) {
        if (!expiryDate) return 'N/A';
        const date = new Date(expiryDate);
        const now = new Date();
        // @ts-ignore
        const diffTime = date - now;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        if (diffDays < 0) return 'Expired';
        if (diffDays === 0) return 'Expires today';
        if (diffDays === 1) return 'Expires tomorrow';
        if (diffDays <= 7) return `Expires in ${diffDays} days`;

        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    /**
     * Get subscription status badge info
     * @param {Object} status - Subscription status object
     * @returns {Object} - Badge info { text, color, bgColor }
     */
    getStatusBadge(status) {
        if (!status) {
            return { text: 'Free', color: '#6b7280', bgColor: '#f3f4f6' };
        }

        if (status.isPro && !status.isExpired) {
            return { text: 'PRO', color: '#10b981', bgColor: '#d1fae5' };
        }

        if (status.isExpired && !status.isCreditsEmpty) {
            return { text: 'Credits Only', color: '#f59e0b', bgColor: '#fef3c7' };
        }

        if (status.isExpired && status.isCreditsEmpty) {
            return { text: 'Expired', color: '#ef4444', bgColor: '#fee2e2' };
        }

        return { text: 'Active', color: '#10b981', bgColor: '#d1fae5' };
    }

    /**
     * Check if user has enough credits
     * @param {number} userCredits - User's current credits
     * @param {number} requiredCredits - Required credits for action
     * @returns {boolean} - True if user has enough credits
     */
    hasEnoughCredits(userCredits, requiredCredits = 1) {
        return userCredits >= requiredCredits;
    }

    /**
     * Prefetch subscription data for user
     * Useful for background loading in app initialization
     * @param {number|string} userId - User ID
     * @param {Object} queryClient - React Query client instance
     */
    prefetchSubscriptionData(userId, queryClient) {
        if (!userId || !queryClient) return;

        // Prefetch subscription status
        queryClient.prefetchQuery({
            queryKey: ['subscription-status', userId],
            queryFn: () => this.getSubscriptionStatus(userId),
            staleTime: 5 * 60 * 1000, // 5 minutes
        });

        // Prefetch subscription history
        queryClient.prefetchQuery({
            queryKey: ['subscription-history', userId],
            queryFn: () => this.getSubscriptionHistory(userId),
            staleTime: 10 * 60 * 1000, // 10 minutes
        });
    }
}

export default new SubscriptionService();