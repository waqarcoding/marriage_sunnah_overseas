import { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import SubscriptionService from '../services/SubscriptionService';

export default function SubscriptionSuccess() {
    const [searchParams] = useSearchParams();
    const navigate = useNavigate();
    const queryClient = useQueryClient();

    const sessionId = searchParams.get('session_id');
    const userId = localStorage.getItem('userId');

    const [isVerifying, setIsVerifying] = useState(true);
    const [error, setError] = useState(null);
    const [success, setSuccess] = useState(false);

    useEffect(() => {
        if (!sessionId) {
            navigate('/subscription');
            return;
        }

        const verify = async () => {
            try {
                const response = await SubscriptionService.verifySession(sessionId);

                console.log('Subscription activated!', response.data);

                setSuccess(true);

                // Refresh subscription-related queries
                // @ts-ignore
                queryClient.invalidateQueries(['subscription-status', userId]);
                // @ts-ignore
                queryClient.invalidateQueries(['user-profile']);

                // Redirect after 3 seconds
                setTimeout(() => {
                    navigate('/');
                }, 3000);
            } catch (err) {
                console.error('Verification error:', err);
                setError(
                    err?.response?.data?.message ||
                    'Something went wrong verifying your payment.'
                );
            } finally {
                setIsVerifying(false);
            }
        };

        verify();
    }, [sessionId, navigate, queryClient, userId]);

    return (
        <div style={styles.container}>
            <div
                // @ts-ignore
                style={styles.card}>
                {isVerifying && (
                    <>
                        <div style={styles.icon}>⏳</div>
                        <h2>Verifying your payment...</h2>
                        <p>Please wait while we activate your subscription.</p>
                    </>
                )}

                {!isVerifying && success && (
                    <>
                        <div style={styles.icon}>🎉</div>
                        <h1>Subscription Successful!</h1>
                        <p>Your subscription has been activated.</p>
                        <p>Redirecting to home...</p>

                        <button style={styles.button} onClick={() => navigate('/')}>
                            Go to Home Now
                        </button>
                    </>
                )}

                {!isVerifying && error && (
                    <>
                        <div style={styles.icon}>❌</div>
                        <h2>Payment Verification Failed</h2>
                        <p>{error}</p>

                        <button
                            style={styles.button}
                            onClick={() => navigate('/subscription')}
                        >
                            Back to Subscription
                        </button>
                    </>
                )}
            </div>
        </div>
    );
}

const styles = {
    container: {
        height: '100vh',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        background: '#f9fafb',
    },
    card: {
        background: '#fff',
        padding: '40px',
        borderRadius: '12px',
        boxShadow: '0 10px 30px rgba(0,0,0,0.1)',
        textAlign: 'center',
        maxWidth: '400px',
        width: '100%',
    },
    icon: {
        fontSize: '48px',
        marginBottom: '16px',
    },
    button: {
        marginTop: '20px',
        padding: '10px 20px',
        borderRadius: '8px',
        border: 'none',
        background: '#2563eb',
        color: '#fff',
        cursor: 'pointer',
        fontSize: '14px',
    },
};