// @ts-nocheck
import { createRoot } from 'react-dom/client';
import { createBrowserRouter, RouterProvider, Navigate, useNavigate, Outlet } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { SocketProvider } from './sockets/SocketContext.jsx';
import AppBar, { INDIVIDUAL_TABS, GUARDIAN_TABS } from './ui/app_bar.jsx';

import ExplorePage from './features/explore/pages/explore_page.jsx';
import Login from './features/auth/pages/login_page.jsx';
import ReferralPage from './features/setting/pages/reffer_page.jsx';
import Register from './features/auth/pages/register_page.jsx';
import Profile from './features/profile/othersprofile/others_profile_page.jsx';
import MyProfile from './features/profile/myprofile/pages/my_profile_page.jsx';
import Match from './features/explore/pages/explore_page.jsx';
import Interest from './features/interest/pages/interest_page.jsx';
import Chat from './features/chat/pages/chat_page.jsx';
import Landing from './features/landing/landing_page.jsx';
import HowItWorks from './features/landing/instruction_page.jsx';
import OtpPage from './features/auth/pages/otp_page.jsx';
import SubscriptionPage from './features/subscription/pages/subscriptions.jsx';
import CompleteProfile from './features/profile/completeprofile/complete_profile_page.jsx';
import VerificationPage from './features/profile/completeprofile/id_verification_page.jsx';
import ForgotPassword from './features/auth/pages/forget_page.jsx';
import GuardianDashboard from './features/guardian/pages/guardian_dashboard.jsx';
import ShowPinPage from './features/profile/myprofile/pages/link_guardian_page.jsx';
import LinkWithPin from './features/guardian/pages/link_ward_page.jsx';
import GuardianProfilePage from './features/guardian/pages/guardian_profile_page.jsx';
import SubscriptionSuccess from './features/subscription/components/subscription_success.jsx';

import './theme/index.css';
import SettingsPage from './features/setting/pages/settings_page.jsx';
import ChangePassword from './features/setting/components/change_page.jsx';
import SubscriptionDetailPage from './features/setting/pages/subscription_detail_page.jsx';
import AppToaster from './ui/toaster.jsx';
import Notifications from './features/notifications/notifications.jsx';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { staleTime: Infinity, gcTime: 1000 * 60 * 30, retry: 1 },
  },
});

function getTokenData() {
  try {
    const token = localStorage.getItem('jwtToken');
    if (!token) return null;
    return JSON.parse(atob(token.split('.')[1]));
  } catch { return null; }
}

function isAuthenticated() {
  return (
    localStorage.getItem('isLoggedIn') === 'true' &&
    localStorage.getItem('isOtpVerified') === 'true'
  );
}

function getUserRole() { return getTokenData()?.role ?? null; }

const logout = () =>
  ['isLoggedIn', 'isOtpVerified', 'jwtToken', 'userId'].forEach(k => localStorage.removeItem(k));

// ── Error Boundary Component ──────────────────────────────────────────────────
function ErrorBoundaryFallback() {
  return (
    <div className="flex items-center justify-center h-screen">
      <div className="text-center p-8">
        <h1 className="text-2xl font-bold mb-4">Oops! Something went wrong</h1>
        <p className="mb-4">Please refresh the page or contact support if the problem persists.</p>
        <button
          onClick={() => window.location.reload()}
          className="px-4 py-2 bg-blue-500 text-white rounded"
        >
          Refresh Page
        </button>
      </div>
    </div>
  );
}

// ── Guards ────────────────────────────────────────────────────────────────────
function RootGuard() {
  if (!isAuthenticated()) return <Landing />;
  const role = getUserRole();
  return role === 'guardian'
    ? <Navigate to="/guardian" replace />
    : <Navigate to="/individual/explore" replace />; // ✅ Changed to /individual/explore
}

function ProtectedRoute({ children, requireRole = null }) {
  if (localStorage.getItem('isLoggedIn') !== 'true') return <Navigate to="/login" replace />;
  if (localStorage.getItem('isOtpVerified') !== 'true') return <Navigate to="/otp" replace />;
  if (requireRole && getUserRole() !== requireRole) return <Navigate to="/" replace />;
  return children;
}

function LoginWrapper() {
  const navigate = useNavigate();
  return <Login onLogin={() => navigate('/otp')} />;
}

// ── Layouts ───────────────────────────────────────────────────────────────────
function IndividualLayout() {
  const navigate = useNavigate();
  const handleLogout = () => { logout(); navigate('/'); };
  return (
    <div className="flex flex-col h-screen" style={{ background: "var(--secondary)" }}>
      <AppBar tabs={INDIVIDUAL_TABS} onLogout={handleLogout} onSidebarLogout={handleLogout} />
      <div className="flex flex-1 min-h-0 pb-16 md:pb-0">
        <div className="flex-1 flex flex-col overflow-auto">
          <Outlet />
        </div>
      </div>
    </div>
  );
}

function GuardianLayout() {
  const navigate = useNavigate();
  const handleLogout = () => { logout(); navigate('/'); };
  return (
    <div className="flex flex-col h-screen" style={{ background: "var(--secondary)" }}>
      <AppBar tabs={GUARDIAN_TABS} onLogout={handleLogout} onSidebarLogout={handleLogout} />
      <div className="flex flex-1 min-h-0 pb-16 md:pb-0">
        <div className="flex-1 flex flex-col overflow-auto">
          <Outlet />
        </div>
      </div>
    </div>
  );
}

// ── Router ────────────────────────────────────────────────────────────────────
const router = createBrowserRouter([
  // ✅ Public Routes
  {
    path: '/',
    element: <RootGuard />,
    errorElement: <ErrorBoundaryFallback />
  },
  { path: '/login', element: <LoginWrapper /> },
  { path: '/register', element: <Register onRegister={() => { }} /> },
  { path: '/otp', element: <OtpPage onSuccess={() => { }} /> },
  { path: '/how', element: <HowItWorks /> },
  { path: '/forget-password', element: <ForgotPassword /> },
  { path: '/change-password', element: <ChangePassword /> },

  // ✅ Subscription Routes (Protected)
  { path: '/subscription', element: <ProtectedRoute><SubscriptionPage /></ProtectedRoute> },
  { path: '/subscription/success', element: <ProtectedRoute><SubscriptionSuccess /></ProtectedRoute> },

  // ✅ Profile Setup Routes (Protected)
  { path: '/profilesetup', element: <ProtectedRoute><CompleteProfile /></ProtectedRoute> },
  { path: '/verification', element: <ProtectedRoute><VerificationPage onSubmit={() => { }} onSkip={() => { }} /></ProtectedRoute> },
  { path: '/profile', element: <ProtectedRoute><Profile onLike={() => { }} onPass={() => { }} /></ProtectedRoute> },

  // ✅ GUARDIAN ROUTES
  {
    path: '/guardian',
    element: <ProtectedRoute requireRole="guardian"><GuardianLayout /></ProtectedRoute>,
    errorElement: <ErrorBoundaryFallback />,
    children: [
      { index: true, element: <GuardianDashboard /> },
      { path: 'add-ward', element: <LinkWithPin /> },
      { path: 'profile', element: <MyProfile onLogout={() => { logout(); }} /> },
      { path: 'chats', element: <Chat /> },
      { path: 'chat/:receiverId', element: <Chat /> },
      { path: 'notifications', element: <Notifications /> },
      { path: 'settings', element: <SettingsPage /> },
      { path: 'referral', element: <ReferralPage /> },
      { path: 'subscription-detail', element: <SubscriptionDetailPage /> },
    ],
  },

  // ✅ INDIVIDUAL ROUTES - CHANGED PATH FROM '/' to '/individual'
  {
    path: '/individual', // ✅ FIXED: No longer conflicts with root '/'
    element: <ProtectedRoute><IndividualLayout /></ProtectedRoute>,
    errorElement: <ErrorBoundaryFallback />,
    children: [
      { index: true, element: <Navigate to="/individual/explore" replace /> }, // ✅ Default redirect
      { path: 'explore', element: <ExplorePage onProfileClick={() => { }} /> },
      { path: 'match', element: <Match onProfileClick={() => { }} /> },
      { path: 'interest', element: <Interest /> },
      { path: 'chats', element: <Chat /> },
      { path: 'chat/:receiverId', element: <Chat /> },
      { path: 'notifications', element: <Notifications /> },
      { path: 'myprofile', element: <MyProfile /> },
      { path: 'settings', element: <SettingsPage /> },
      { path: 'referral', element: <ReferralPage /> },
      { path: 'show-pin', element: <ShowPinPage /> },
      { path: 'subscription-detail', element: <SubscriptionDetailPage /> },
    ],
  },
]);

// ── Root app with SocketProvider at top level ─────────────────────────────────
function AppRoot() {
  const user = getTokenData();
  // ✅ Use a stable userId or null to prevent unnecessary socket reconnections
  const userId = user?.id ?? null;

  return (
    <SocketProvider userId={userId}>
      <AppToaster />
      <RouterProvider router={router} />
    </SocketProvider>
  );
}

createRoot(document.getElementById('root')).render(
  <QueryClientProvider client={queryClient}>
    <AppRoot />
  </QueryClientProvider>
);